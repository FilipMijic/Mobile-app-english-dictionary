package com.example.projekatrecnik;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Detaljnije extends AppCompatActivity implements View.OnClickListener{
    private Button sacuvaj;
    private Button sinonimi;
    private String rec;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detaljnije);

        sacuvaj=(Button) findViewById(R.id.dugmeZapamti);
        sacuvaj.setOnClickListener(this);

        sinonimi=(Button) findViewById(R.id.dugmeSinonimi);
        sinonimi.setOnClickListener(this);

        rec = getIntent().getStringExtra("ID_RECI");
        Rec r = Api.detaljno(rec);

        StringBuilder sb = new StringBuilder(r.getKratkaDefinicija());
        for (int i = 0;i<sb.length();i++)
        {
            if (i>1 && i<sb.length()-2)
            {
                if(sb.charAt(i-1)=='\"'&& sb.charAt(i)==',' && sb.charAt(i+1)=='\"')
                {

                    sb.replace(i-1,i+2,"\n\n");
                    i-=2;
                }
            }
        }
        r.setKratkaDefinicija(sb.toString().substring(0,sb.toString().length()-1));

        ((TextView)findViewById(R.id.labelaRec)).setText(r.getId());
        ((TextView)findViewById(R.id.labelaIzgovor)).setText(r.getIzgovor());
        ((TextView)findViewById(R.id.labelaGodinaNastanka)).setText(r.getGodinaNastanka());
        ((TextView)findViewById(R.id.labelaVrstaReci)).setText(r.getVrstaReci());
        ((TextView)findViewById(R.id.labelaKratkaDefinicija)).setText(r.getKratkaDefinicija());

    }

    @Override
    public void onClick(View view) {

        if(view.getId() == findViewById(R.id.dugmeZapamti).getId()) {
            SharedPreferences sharedPreferences = getSharedPreferences(MainActivity.SHERED_PREFERENCES_PREF, 0);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putInt("Iterator", 0);

            int iterator = sharedPreferences.getInt("Iterator", 0);
            boolean existing = false;
            String recId = ((TextView) findViewById(R.id.labelaRec)).getText().toString();
            String uporedi = sharedPreferences.getString("Rec:" + iterator, "");
            for (int i = 1; i <= iterator; i++) {
                if (recId.equals(uporedi)) {
                    existing = true;
                }
            }
            if (!existing) {
                iterator++;

                editor.putInt("Iterator", iterator);
                editor.putString("Rec:" + iterator, ((TextView) findViewById(R.id.labelaRec)).getText().toString());
                editor.commit();

                Toast.makeText(Detaljnije.this, "Succesfully saved", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(Detaljnije.this, "Word already saved", Toast.LENGTH_SHORT).show();
            }
        }else if(view.getId() == findViewById(R.id.dugmeSinonimi).getId())
        {
            Intent intent = new Intent(this,Sinonimi.class);
            intent.putExtra("SINONIM",this.rec);
            startActivity(intent);
        }
    }
}