package com.example.projekatrecnik;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Konekcija extends AsyncTask<Void,Void,String> {
    String trazenaRec="";
    String kraj="";
    String data= "";
    @Override
    protected String doInBackground(Void... voids)
    {

        URL url = null;
        try {

            url = new URL("https://www.dictionaryapi.com/api/v3/references/collegiate/json/" + trazenaRec + "?key=00ad1be0-c524-4b27-a3f8-571c21d9a962");

            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

            String red = "";
            while(red != null )
            {
                red = bufferedReader.readLine();
                if (red != null)
                {
                    data += red+"\n";
                }
            }
            MainActivity.data= data;
            kraj=data;

        }catch(Exception e)
        {

        }
        return data;
    }
}




