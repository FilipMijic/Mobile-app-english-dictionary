package com.example.projekatrecnik;

import java.util.ArrayList;
import java.util.LinkedList;

public class Api {
    public static String trazenaRec;
    public static String odgovor;

    public static ArrayList<String> DobaviSinonime(String rec)
    {
        String sinonimiZaObradu = "";
        ArrayList<String> sinonimi = new ArrayList<>();

        StringBuilder sb = new StringBuilder(rec);
        for (int i = 0;i<sb.length();i++)
        {
            if (sb.charAt(i)==':'|| sb.charAt(i)=='1'|| sb.charAt(i)=='2'|| sb.charAt(i)=='3'|| sb.charAt(i)=='4'|| sb.charAt(i)=='5'|| sb.charAt(i)=='6'|| sb.charAt(i)=='7'|| sb.charAt(i)=='8'|| sb.charAt(i)=='9'|| sb.charAt(i)=='0')
            {
                sb.deleteCharAt(i);
                i--;
            }
        }
        rec = sb.toString();

        KonekcijaSin konS = new KonekcijaSin();
        konS.trazenaRec = rec;
        konS.execute();
        try {

            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        while (konS.kraj == "") {

        }
        String zaObradu = MainActivity.data;
        String temp = "";

        for (int i = 0; i < zaObradu.length(); i++)
        {
            temp += zaObradu.charAt(i);
            if (temp.contains("\"syns\":") && sinonimiZaObradu == "") {
                i += 2;
                temp = "";
                while (zaObradu.charAt(i) != ']') {
                    if (zaObradu.charAt(i) != ']') {
                        temp += zaObradu.charAt(i);
                        i++;
                    }
                }
                sinonimiZaObradu = temp;
                temp = "";
            }
        }
        temp="";
        for (int i = 0; i < sinonimiZaObradu.length(); i++)
        {
            temp += sinonimiZaObradu.charAt(i);
            if (sinonimiZaObradu.charAt(i) == '\"') {
                i++;
                temp = "";
                while (sinonimiZaObradu.charAt(i) != '\"') {
                    if (sinonimiZaObradu.charAt(i) != '\"') {
                        temp += sinonimiZaObradu.charAt(i);
                        i++;
                    }
                }
                sinonimi.add(temp);
                i++;
                temp = "";

            }
        }





        return sinonimi;
    }

    public static Rec detaljno(String rec) {
        String id = "";
        String izgovor = "";
        String vrstaReci = "";
        String godinaNastanka = "";
        String kratkaDefinicija = "";

        StringBuilder sb = new StringBuilder(rec);
        for (int i = 0;i<sb.length();i++)
        {
            if (sb.charAt(i)==':'|| sb.charAt(i)=='1'|| sb.charAt(i)=='2'|| sb.charAt(i)=='3'|| sb.charAt(i)=='4'|| sb.charAt(i)=='5'|| sb.charAt(i)=='6'|| sb.charAt(i)=='7'|| sb.charAt(i)=='8'|| sb.charAt(i)=='9'|| sb.charAt(i)=='0')
            {
                sb.deleteCharAt(i);
                i--;
            }
        }
        rec = sb.toString();

        Konekcija kon = new Konekcija();
        kon.trazenaRec = rec;
        kon.execute();
        try {

            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        while (kon.kraj == "") {

        }
        String zaObradu = MainActivity.data;
        String temp = "";
        for (int i = 0; i < zaObradu.length(); i++) {
            temp += zaObradu.charAt(i);
            if (temp.contains("\"id\":") && id == "") {
                i += 2;
                temp = "";
                while (zaObradu.charAt(i) != '\"') {
                    if (zaObradu.charAt(i) != '\"') {
                        temp += zaObradu.charAt(i);
                        i++;
                    }
                }
                id = temp;
                temp = "";
            } else if (temp.contains("hw\":") && izgovor == "") {
                i += 2;
                temp = "";
                while (zaObradu.charAt(i) != '\"') {
                    if (zaObradu.charAt(i) != '\"') {
                        temp += zaObradu.charAt(i);
                        i++;
                    }
                }
                izgovor = temp;
                temp = "";
            } else if (temp.contains("fl\":") && vrstaReci == "") {
                i += 2;
                temp = "";
                while (zaObradu.charAt(i) != '\"') {
                    if (zaObradu.charAt(i) != '\"') {
                        temp += zaObradu.charAt(i);
                        i++;
                    }
                }
                vrstaReci = temp;
                temp = "";
            } else if (temp.contains("date\":") && godinaNastanka == "") {
                i += 2;
                temp = "";
                while (zaObradu.charAt(i) != '\"') {
                    if (zaObradu.charAt(i) != '\"') {
                        temp += zaObradu.charAt(i);
                        i++;
                    }
                }
                godinaNastanka = temp;
                temp = "";
            } else if (temp.contains("shortdef\":") && kratkaDefinicija == "") {
                i += 3;
                temp = "";
                while (zaObradu.charAt(i) != ']') {
                    if (zaObradu.charAt(i) != ']') {
                        temp += zaObradu.charAt(i);
                        i++;
                    }
                }
                kratkaDefinicija = temp;
                temp = "";
                //TODO razdvojiti definicije
            }


        }
        return new Rec(rec, id, izgovor, vrstaReci, godinaNastanka, kratkaDefinicija);
    }

    public static LinkedList<Rec> dohvatiSacuvane(String[] spisakReci)
    {
        LinkedList<Rec> list = new LinkedList<>();
        String id="";
        for(int i = 0;i<spisakReci.length;i++)
        {
            id=spisakReci[i];
            list.add(detaljno(id));
        }
        return list;
    }

    public static LinkedList<Rec> pretrazi(String rec) {
        String id = "";
        String izgovor = "";
        String vrstaReci = "";
        String godinaNastanka = "";
        String kratkaDefinicija = "";

        LinkedList<Rec> reci = new LinkedList<>();

        Konekcija konekcija = new Konekcija();
        konekcija.trazenaRec = rec;
        konekcija.execute();
        try {

            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        while (konekcija.kraj == "") {

        }

        String zaObradu = MainActivity.data;
        String temp = "";
        LinkedList<String> delovi = new LinkedList<>();
        for(int i = 10;i<zaObradu.length();i++)
        {
            temp+=zaObradu.charAt(i);
            if (temp.contains("meta"))
            {
                delovi.add(temp);
                temp="";
            }
        }
        delovi.add(temp);
        temp="";

        for(String r:delovi)
        {
            String deo = r;

            for (int i = 0; i < r.length(); i++) {
                temp += r.charAt(i);


                if (temp.contains("\"id\":") && id == "") {
                    i += 2;
                    temp = "";
                    while (r.charAt(i) != '\"') {
                        if (r.charAt(i) != '\"') {
                            temp += r.charAt(i);
                            i++;
                        }
                    }
                    id = temp;
                    temp = "";
                } else if (temp.contains("hw\":") && izgovor == "") {
                    i += 2;
                    temp = "";
                    while (r.charAt(i) != '\"') {
                        if (r.charAt(i) != '\"') {
                            temp += r.charAt(i);
                            i++;
                        }
                    }
                    izgovor = temp;
                    temp = "";
                } else if (temp.contains("fl\":") && vrstaReci == "") {
                    i += 2;
                    temp = "";
                    while (r.charAt(i) != '\"') {
                        if (r.charAt(i) != '\"') {
                            temp += r.charAt(i);
                            i++;
                        }
                    }
                    vrstaReci = temp;
                    temp = "";
                } else if (temp.contains("date\":") && godinaNastanka == "") {
                    i += 2;
                    temp = "";
                    while (r.charAt(i) != '\"') {
                        if (r.charAt(i) != '\"') {
                            temp += r.charAt(i);
                            i++;
                        }
                    }
                    godinaNastanka = temp;
                    temp = "";
                } else if (temp.contains("shortdef\":") && kratkaDefinicija == "") {
                    i += 3;
                    temp = "";
                    while (r.charAt(i) != ']') {
                        if (r.charAt(i) != ']') {
                            temp += r.charAt(i);
                            i++;
                        }
                    }
                    kratkaDefinicija = temp;
                    temp = "";

                }


            }
            reci.add(new Rec(rec, id, izgovor, vrstaReci, godinaNastanka, kratkaDefinicija));
            id = "";
            izgovor = "";
            vrstaReci = "";
            godinaNastanka = "";
            kratkaDefinicija = "";

        }


        return reci;
    }

}
