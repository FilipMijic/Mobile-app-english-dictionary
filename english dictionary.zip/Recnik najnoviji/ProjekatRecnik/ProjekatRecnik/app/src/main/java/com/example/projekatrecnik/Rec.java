package com.example.projekatrecnik;

public class Rec {
    private String rec,id,izgovor, vrstaReci,godinaNastanka,kratkaDefinicija;

    public void setRec(String rec) {
        this.rec = rec;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setIzgovor(String izgovor) {
        this.izgovor = izgovor;
    }

    public void setVrstaReci(String vrstaReci) {
        this.vrstaReci = vrstaReci;
    }

    public void setGodinaNastanka(String godinaNastanka) {
        this.godinaNastanka = godinaNastanka;
    }

    public void setKratkaDefinicija(String kratkaDefinicija) {
        this.kratkaDefinicija = kratkaDefinicija;
    }

    public String getRec() {
        return rec;
    }

    public String getId() {
        return id;
    }

    public String getIzgovor() {
        return izgovor;
    }

    public String getVrstaReci() {
        return vrstaReci;
    }

    public String getGodinaNastanka() {
        return godinaNastanka;
    }

    public String getKratkaDefinicija() {
        return kratkaDefinicija;
    }

    public Rec(String rec, String id, String izgovor, String vrstaReci, String godinaNastanka, String kratkaDefinicija) {
        this.rec = rec;
        this.id = id;
        this.izgovor = izgovor;
        this.vrstaReci = vrstaReci;
        this.godinaNastanka = godinaNastanka;
        this.kratkaDefinicija = kratkaDefinicija;
    }
}
