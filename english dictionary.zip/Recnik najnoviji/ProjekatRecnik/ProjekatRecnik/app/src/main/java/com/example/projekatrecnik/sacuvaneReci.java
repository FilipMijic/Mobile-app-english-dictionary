package com.example.projekatrecnik;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.LinkedList;

public class sacuvaneReci extends AppCompatActivity implements View.OnClickListener{
    private ListView lista;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sacuvane_reci);

        lista = findViewById(R.id.listaSacuvane);
        findViewById(R.id.ukloniSacuvane).setOnClickListener(this);
        SharedPreferences sharedPreferences = getSharedPreferences(MainActivity.SHERED_PREFERENCES_PREF,0);
        int iterator = sharedPreferences.getInt("Iterator",0);

        ArrayList<String> sacuvaneReci = new ArrayList<>();

        for (int i = 1; i<= iterator;i++) {
            sacuvaneReci.add(sharedPreferences.getString("Rec:"+i,""));
        }

        int nekiBroj = 0;
        String[] tempReci = new String[sacuvaneReci.size()];
        for(String s:sacuvaneReci)
        {
                tempReci[nekiBroj]=s;
                nekiBroj++;
        }



        LinkedList<Rec> reci = Api.dohvatiSacuvane(tempReci);

        String[] sveReci= new String[reci.size()];
        int i = 0;
        for (Rec r:reci)
        {
            sveReci[i]=r.getId();
            i++;
        }


        final ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, sveReci);

        lista.setAdapter(adapter);
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                String id = adapter.getItem(i).toString();

                Intent intent = new Intent(getApplicationContext(), Detaljnije.class);
                intent.putExtra("ID_RECI", id);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onClick(View view) {

        if (view.getId() == R.id.ukloniSacuvane) {
            SharedPreferences sharedPreferences = getSharedPreferences(MainActivity.SHERED_PREFERENCES_PREF, 0);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.clear();
            editor.commit();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
    }
}