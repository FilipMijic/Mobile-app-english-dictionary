package com.example.projekatrecnik;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Sinonimi extends AppCompatActivity implements View.OnClickListener {
    public static String rec;
    private ListView lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sinonimi);

        rec = getIntent().getStringExtra("SINONIM");
        ArrayList<String> reci =  Api.DobaviSinonime(rec);
        String[] sveReci=new String[reci.size()];
        int i = 0;
        for (String rec:reci)
        {
            sveReci[i]=rec;
            i++;
        }

        lista = findViewById(R.id.listaSinonima);

        final ArrayAdapter adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,sveReci);

        lista.setAdapter(adapter);
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                String id = adapter.getItem(i).toString();

                Intent intent = new Intent(getApplicationContext(),Detaljnije.class);
                intent.putExtra("ID_RECI", id);
                startActivity(intent);
            }
        });
    }


    @Override
    public void onClick(View view) {

    }
}