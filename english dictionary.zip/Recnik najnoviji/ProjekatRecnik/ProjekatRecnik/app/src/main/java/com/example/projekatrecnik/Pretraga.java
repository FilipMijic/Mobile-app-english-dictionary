package com.example.projekatrecnik;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.LinkedList;

public class Pretraga extends AppCompatActivity {
    private ListView lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pretraga);


        lista = findViewById(R.id.listaPretraga);

        String rec = getIntent().getStringExtra("PRETRAGA");
        LinkedList<Rec> reci = Api.pretrazi(rec);

        String[] sveReci= new String[reci.size()];
        int i = 0;
        for (Rec r:reci)
        {
            sveReci[i]=r.getId();
            i++;
        }


        final ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, sveReci);

        lista.setAdapter(adapter);
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                String id = adapter.getItem(i).toString();

                Intent intent = new Intent(getApplicationContext(), Detaljnije.class);
                intent.putExtra("ID_RECI", id);
                startActivity(intent);
            }
        });



    }
}
