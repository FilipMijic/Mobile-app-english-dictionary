package com.example.projekatrecnik;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class KonekcijaSin extends AsyncTask<Void,Void,String> {
    String trazenaRec="";
    String kraj="";
    String data= "";
    @Override
    protected String doInBackground(Void... voids)
    {

        URL url = null;
        try {

            url = new URL("https://www.dictionaryapi.com/api/v3/references/thesaurus/json/" + trazenaRec + "?key=0f73e198-bc6e-4cd0-b61f-e8b6daf9f6f0");

            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

            String red = "";
            while(red != null )
            {
                red = bufferedReader.readLine();
                if (red != null)
                {
                    data += red+"\n";
                }
            }
            MainActivity.data= data;
            kraj=data;

        }catch(Exception e)
        {

        }
        return data;
    }
}