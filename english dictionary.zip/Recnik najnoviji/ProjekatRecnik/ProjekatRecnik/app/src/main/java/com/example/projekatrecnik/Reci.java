package com.example.projekatrecnik;

import java.util.ArrayList;


public class Reci {

    public static ArrayList<String> DobaviReci()
    {
        ArrayList<String> reci = new ArrayList<>();
        reci.add("ability");
        reci.add("breakfast");
        reci.add("abort");
        reci.add("about");
        reci.add("above");
        reci.add("abroad");
        reci.add("absence");
        reci.add("absolute");
        reci.add("absolutely");
        reci.add("absorb");
        reci.add("academic");
        reci.add("abased");
        reci.add("accept");
        reci.add("access");
        reci.add("accident");
        reci.add("accompany");
        reci.add("accomplish");
        reci.add("according");
        reci.add("accurate");
        reci.add("account");
        return  reci;
    }
}
