package com.example.projekatrecnik;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    public static String data;
    private ListView lista;
    public static String SHERED_PREFERENCES_PREF = "ListaSacuvanih";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        ArrayList<String> reci = Reci.DobaviReci();
        String[] sveReci=new String[reci.size()];
        int i = 0;
        for (String rec:reci)
        {
            sveReci[i]=rec;
            i++;
        }

        lista = findViewById(R.id.listView);

        final ArrayAdapter adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,sveReci);
        findViewById(R.id.pronadjiRec).setOnClickListener(this);
        findViewById(R.id.sacuvaneReci).setOnClickListener(this);
        lista.setAdapter(adapter);
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                String id = adapter.getItem(i).toString();

                Intent intent = new Intent(getApplicationContext(),Detaljnije.class);
                intent.putExtra("ID_RECI", id);
                startActivity(intent);
            }
        });


    }

    @Override
    public void onClick(View view) {
        if(view.getId() == findViewById(R.id.pronadjiRec).getId())
        {
            Intent intent = new Intent(this,Pretraga.class);
            intent.putExtra("PRETRAGA",((TextView) findViewById(R.id.tekstPoljeRecZaPretragu)).getText().toString() );
            startActivity(intent);
        }else if(view.getId() == findViewById(R.id.sacuvaneReci).getId())
        {
            Intent intent = new Intent(this,sacuvaneReci.class);
            startActivity(intent);
        }

    }
}